﻿using System;
using Xamarin.Forms;

namespace PopupLayoutsForms
{
    public class GridView:Grid
    {
        public GridView(ContentPage parentPage, PopupLayouts parentPopupLayout)
        {
 
            var col1 = new ColumnDefinition();
            var col2 = new ColumnDefinition();
            var col3 = new ColumnDefinition();
            HorizontalOptions = LayoutOptions.FillAndExpand;
            VerticalOptions = LayoutOptions.StartAndExpand;
            ColumnSpacing = 1;
            RowSpacing = 1;
            Padding = 1;

            BackgroundColor = Color.Gray.WithLuminosity(.9);

            this.ColumnDefinitions.Add(col1);
            this.ColumnDefinitions.Add(col2);
            this.ColumnDefinitions.Add(col3);
            int r = 0;
            int col = 0;
            for (int i = 0; i < 21; i++)
            {
                this.RowDefinitions.Add(new RowDefinition());
                var cellStack = new StackLayout
                {
                    HorizontalOptions = LayoutOptions.FillAndExpand,
                    VerticalOptions = LayoutOptions.StartAndExpand,
                    Padding = 1,
                    BackgroundColor = Color.White,
                };
                var imageCell = new Image
                {
                    Source = ImageSource.FromFile("dc.jpg"),
                    WidthRequest = parentPage.Width / 3 - parentPage.Padding.HorizontalThickness,
                    HeightRequest = parentPage.Width / 3 - parentPage.Padding.VerticalThickness, 
                    Aspect = Aspect.AspectFill,
                    HorizontalOptions = LayoutOptions.FillAndExpand,
                    VerticalOptions = LayoutOptions.StartAndExpand,
                    //HeightRequest = 100,
                    
                };
                
              
                var tapGestureRecognizer = new TapGestureRecognizer();
                if (i % 2 == 0)
                {
                    tapGestureRecognizer.Tapped += (s, e) =>
                        parentPopupLayout.ShowPopupByMargin(new PopupSampleContent(parentPopupLayout), new Rectangle(.10, 0, .10, .60), true, false, "Flush Top");
                }
                else if (i % 3 == 0)
                {
                 
                    tapGestureRecognizer.Tapped += (s, e) =>
                        parentPopupLayout.ShowPopupByMargin(new PopupSampleContent(parentPopupLayout), new Rectangle(0, 0, .35, 0), true, false, "Flush Left");
                }
                else if (i % 5 == 0)
                {

                    tapGestureRecognizer.Tapped += (s, e) =>
                        parentPopupLayout.ShowPopupByMargin(new PopupSampleContent(parentPopupLayout), new Rectangle(.35, 0, 0, 0), true, false, "Flush Right");
                }
                else if (i % 6 == 0)
                {

                    tapGestureRecognizer.Tapped += (s, e) =>
                        parentPopupLayout.ShowPopupCenter(new PopupSampleContent(parentPopupLayout), 1, "100% Center Modal", true, false);
                }
                else
                {

                    tapGestureRecognizer.Tapped += (s, e) =>
                        parentPopupLayout.ShowPopupByMargin(new PopupSampleContent(parentPopupLayout), new Rectangle(.15, .40, .15, 0), true, false, "Flush Bottom");
                }

                imageCell.GestureRecognizers.Add(tapGestureRecognizer);
                cellStack.Children.Add(imageCell);
                this.Children.Add(cellStack, col, r); 
                var button = new Button
                {
                    Text = "Popup #" + i.ToString(),
                    HorizontalOptions = LayoutOptions.FillAndExpand,
                    VerticalOptions = LayoutOptions.Start,
                    BackgroundColor = Color.Gray.WithLuminosity(.9),
                    HeightRequest = Device.OnPlatform(28, 36, 36),
                    TextColor = Device.OnPlatform(Color.Default, Color.Black, Color.Black),
                    BorderColor = Color.Black.WithLuminosity(.7),
                    BorderRadius = 0,
                    BorderWidth = 1, 
                };
               
                button.Clicked += ((object sender, EventArgs e) =>
              
                    parentPopupLayout.ShowPopupRelative(new PopupSampleContent(parentPopupLayout), relativeTo: button, width: 200, height: 260, modal: true, title: button.Text));
                var buttonStack = new StackLayout
                {
                    HorizontalOptions = LayoutOptions.FillAndExpand,
                    VerticalOptions = LayoutOptions.StartAndExpand,
                    Padding = 1,
                    HeightRequest = Device.OnPlatform(28, 36, 36),
                    BackgroundColor = Color.Gray.WithLuminosity(.9),
                };
                buttonStack.Children.Add(button);
                cellStack.Children.Add(buttonStack);
                col += 1;
                if (col == 3)
                {
                    col = 0;
                    r++;
                }
            }
        }

    }
}

