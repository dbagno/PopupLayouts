﻿using System;
using Xamarin.Forms;

namespace PopupLayoutsForms
{
    public class PopupSampleContent:TableView
    {
        public PopupSampleContent(PopupLayouts parentPopup)
        {
            if (parentPopup != null)
            {
                TableRoot tr = new TableRoot();
                HasUnevenRows = false;
                BackgroundColor = Device.OnPlatform(Color.White, Color.Black, Color.White);//need black for android
                TableSection ts = new TableSection("");

                tr.Add(ts);
                for (var i = 0; i < 30; i++)
                {
                    var nextSwitch = new SwitchCell { Text = "Switch Cell #" + i };

                    nextSwitch.OnChanged += ((object sender, ToggledEventArgs e) =>
                    {
                        //raised Change event in the content window containing the popup
                        parentPopup.PopupChanged = true;
                    });
                    ts.Add(nextSwitch);
                }
                this.Root = tr; 
            }
           

        }
    }
}

