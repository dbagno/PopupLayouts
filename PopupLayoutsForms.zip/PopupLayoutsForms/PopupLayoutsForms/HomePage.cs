﻿using System;

using Xamarin.Forms;

namespace PopupLayoutsForms
{
    public class HomePage : ContentPage
    {
        public PopupLayouts PopupContent { get; set; }

        private double _width = 0;
        private double _height = 0;

        private StackLayout PageStack{ get; set; }

        private ScrollView PageScroll{ get; set; }

        private ToolbarItem PopupButton{ get; set; }

        private PopupSampleContent AnyView{ get; set; }

        public HomePage()
        {
            this.Title = "PopupLayouts";
            Padding = 0;
            PopupButton = new ToolbarItem
            {
                Text = "Show Popup",
                Priority = 0
            };
            Content = new StackLayout
            { 
                Children =
                {
                    new Label { Text = "Hello ContentPage" }
                }
            };
           
            ToolbarItems.Add(PopupButton);
            PopupButton.Clicked += ((object sender, EventArgs e) =>
            {
                if (!PopupContent.PopupVisible)
                {
                    #region popup content

                    //optional remove popup toolbaritem from navigation bar if modal
                    //first parameter required any View
                    //second parameter scale size of center popup min=.25 max=1 default=.80
                    //third parameter optional title
                    //fourth parameter optional modal default is true
                    //fifth paramater optional parameter optional rounded border default=false ** if scale of 1 don't use rounded borders not recommended
                    PopupContent.ShowPopupCenter(AnyView, 8, title: "Centered Rounded Modal", modal: true, rounded: true);


                    #endregion
                }
                else
                {
                    PopupContent.DismisPopup();
                }
            });
        }

        public void DrawScreen()
        {
            PageStack = new StackLayout
            {
                HorizontalOptions = LayoutOptions.FillAndExpand,
                VerticalOptions = LayoutOptions.FillAndExpand,
                Padding = 0,
                BackgroundColor = Device.OnPlatform(Color.White, Color.Black, Color.White),
            };
           
            PageScroll = new ScrollView
            {
                Content = PageStack
            };
            if (PopupContent == null)
            {
                //first parameter will take any View 
                //second parameter a reference to the current content window
                //third parameter optional parent scroll view if you want relative popups to show relative to scroll position
                PopupContent = new PopupLayouts(PageScroll, this, PageScroll);

            }
            Content = PopupContent;
            PageStack.Children.Add(new GridView(this, PopupContent));
            AnyView = new PopupSampleContent(PopupContent);//pass the content window's PopupContent
            PopupContent.Opened += () =>
            {
                //popup opened event for locking elements if needed
                if (ToolbarItems.Contains(PopupButton))
                {
                    ToolbarItems.Remove(PopupButton); 
                }

            };
            PopupContent.Closed += ((bool changed) =>
            {
                //unlock any locked  elements here
                if (!ToolbarItems.Contains(PopupButton))
                {
                    //put the toolbaritem back in navigation bar
                    ToolbarItems.Add(PopupButton);
                }
                if (changed)
                {
                    //call code to respond to the controls changed within the popup view.
                    DisplayAlert("Popup Status", "This popup has changed!", "OK");
                }
            });
        }

        protected override void OnSizeAllocated(double width, double height)
        {
            base.OnSizeAllocated(width, height);
            //this instantiation and creation of the window’s content should be called from OnSizeAllocated event.  This is the only way to insure that the window and popup will be dynamically resized on orientation changes.
            if (Math.Abs(this._width - width) > .001 || Math.Abs(this._height - height) > .001)
            {
                this._width = width;
                this._height = height;
                if (PopupContent == null || !PopupContent.PopupVisible)
                {
                    DrawScreen();

                }
            }
        }
    }
}


